#!/usr/bin/env bash

SERVER_NAME=""					#имя сервера, используется в именах файлов
DATE=`date +%Y-%m-%d_%Hh%Mm`			#формат времени, используется в именах фалов
PATH_MIKBILL=/var/www/mikbill/admin/	#путь к админке MikBill
LIFE_TIME_FILE_ON_DISk=10				#количество дней хранения файлов, что ранее - удаляется

#удалим инсталлер
if [ -f "./dropbox_backups_installer.sh" ]; then rm ./dropbox_backups_installer.sh; fi

#Создаем дамп базы mikbill, сохраняем в /home/dropbox/files
db_user=$(cat $PATH_MIKBILL'app/etc/config.xml'| grep  username | awk '{ gsub("<username>"," "); print }' | awk '{ gsub("</username>"," "); print }' | awk '{print $1}')
db_password=$(cat $PATH_MIKBILL'app/etc/config.xml'| grep  password | awk '{ gsub("<password>"," "); print }' | awk '{ gsub("</password>"," "); print }' | awk '{print $1}')
FILENAME=sqldump-mikbill-"$SERVER_NAME"-"$DATE".sql.gz
mysqldump -u $db_user -p$db_password mikbill | gzip > $BACKUP_FILES_DIR/$FILENAME
cp $BACKUP_FILES_DIR/$FILENAME $BACKUP_FILES_DIR/_sqldump-mikbill-"$SERVER_NAME".sql.gz

#Создаем архив важных файлов
FILENAME=files-mikbill-"$SERVER_NAME"-"$DATE".tar.gz
tar -X $BACKUP_SCRIPT_DIR/exclude.list -T $BACKUP_SCRIPT_DIR/include.list -czf $BACKUP_FILES_DIR/$FILENAME
cp $BACKUP_FILES_DIR/$FILENAME $BACKUP_FILES_DIR/_files-mikbill-"$SERVER_NAME".tar.gz

#Заливаем бекапы в dropbox
$BACKUP_SCRIPT_DIR/dropbox_uploader.sh upload $BACKUP_FILES_DIR/_sqldump-mikbill-"$SERVER_NAME".sql.gz /
$BACKUP_SCRIPT_DIR/dropbox_uploader.sh upload $BACKUP_FILES_DIR/_files-mikbill-"$SERVER_NAME".tar.gz /

#Удаляем старые
find $BACKUP_FILES_DIR -mtime +$LIFE_TIME_FILE_ON_DISk |sort|xargs rm -f
