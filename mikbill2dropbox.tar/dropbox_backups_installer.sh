#!/usr/bin/env bash

curl "https://raw.githubusercontent.com/andreafabrizi/Dropbox-Uploader/master/dropbox_uploader.sh" -o dropbox_uploader.sh
chmod +x dropbox_uploader.sh
sh ./dropbox_uploader.sh

BACKUP_FILES_DIR=/${PWD##/}/files
BACKUP_SCRIPT_DIR=/${PWD##/}

sed -i 's/CONFIG_FILE=~\/./CONFIG_FILE=.\//' ./dropbox_uploader.sh
cp /root/.dropbox_uploader $BACKUP_SCRIPT_DIR/dropbox_uploader

sed -i 4i\ 'BACKUP_FILES_DIR=/'${PWD##/}'/files' create_backups.sh
sed -i 4i\ 'BACKUP_SCRIPT_DIR=/'${PWD##/} create_backups.sh
sed -i 1i\ $BACKUP_SCRIPT_DIR include.list
sed -i 1i\ $BACKUP_FILES_DIR'/*' exclude.list

echo "" >> /etc/crontab
echo "#mysqldump & files backup to '"$BACKUP_FILES_DIR"' and upload to dropbox" >> /etc/crontab
echo "00 06 * * * root "$BACKUP_SCRIPT_DIR"/create_backups.sh"  >> /etc/crontab
